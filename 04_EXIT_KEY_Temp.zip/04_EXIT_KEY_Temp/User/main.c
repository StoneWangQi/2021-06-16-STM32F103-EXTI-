/**
  ******************************************************************************
  * @file    GPIO/JTAG_Remap/main.c 
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    08-April-2011
  * @brief   Main program body
  ******************************************************************************
  * @attention
  *
  * 
  ******************************************************************************
  */ 

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "PROJ_book.h" 

/* Private functions ---------------------------------------------------------*/

/**
  * @brief  Main program.
  * @param  None
  * @retval None
  */
void delay(int x);
void fn_Main_Init(void);
int main(void)
{ 


      fn_Led_Init();
      fn_Key_Init();
      fn_Main_Init();     
      fn_EXTI_GPIO_Config();
      while(1){
       // fn_key_Check();
        delay(10000);
      }
}

void fn_Main_Init(void){
  uint16_t  count_Init = 2;
  while(count_Init-->0){
    __LED_Change__;
    fn_Systick_Delay(500,_Systick_ms);
    __LED_Change__;
    fn_Systick_Delay(100,_Systick_ms);
    __LED_Change__;
    fn_Systick_Delay(100,_Systick_ms);
    __LED_Change__;
    fn_Systick_Delay(500,_Systick_ms);
  } 
}

void delay(int x){
	int y = 0xFFFFF;
	while((x--)>0){
		while((y--)>0){
			__NOP();
			__NOP();
			__NOP();
			__NOP();
			__NOP();
		}
	}
}
/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
